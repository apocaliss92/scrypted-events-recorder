# Scrypted events recorder

Allows recording of videoclips when detections happen. 

Recording clips are not in a very good shape yet. The whole flow is fully functional though
- generates clips according to the user settings
- stores and auto-remove oldest clips on memory allocated full
- retrieve clips on any scrypted interface